#ifndef TEST_BLOCK_EFFECT_GLSL
#define TEST_BLOCK_EFFECT_GLSL

// Marker colour of the test_block texture (12, 250, 77), alpha stays 255 -> block stays in the SOLID layer
const vec3 TB_MARKER = vec3(12.0, 250.0, 77.0) / 255.0;
bool tb_isMarker(vec3 rgb) {
    return all(lessThan(abs(rgb - TB_MARKER), vec3(1.5 / 255.0)));
}

const float TB_TAU      = 6.28318530718;
const float TB_LOOP     = 12.0;            // seconds, whole animation loops seamlessly
const float TB_SCALE    = 4.0;             // voronoi cells per block
const float TB_CELLS    = 16.0 * TB_SCALE; // cells per 16 blocks -> pattern wraps seamlessly

// ---------- tweakables ----------
const float TB_CLOUD_CELLS = 4.0;   // cloud blobs per 16 blocks (bigger = smaller clouds); must be an integer
const float TB_BUBBLE_RMIN = 0.15;  // smallest bubble radius (in cells)
const float TB_BUBBLE_RMAX = 0.30;  // biggest bubble radius (in cells)
const vec3  TB_RED  = vec3(0.90, 0.05, 0.10);
const vec3  TB_BLUE = vec3(0.10, 0.20, 0.95);

// ---------- hashes (no sin: stable on every GPU) ----------
float tb_hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}

vec3 tb_hash33(vec3 p) {
    p = vec3(dot(p, vec3(127.1, 311.7, 74.7)),
             dot(p, vec3(269.5, 183.3, 246.1)),
             dot(p, vec3(113.5, 271.9, 124.6)));
    return fract(sin(p) * 43758.5453123);
}

// ---------- periodic 3D value noise ----------
float tb_vnoise(vec3 p, float period) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    vec3 u = f * f * (3.0 - 2.0 * f);
    float n000 = tb_hash13(mod(i,                     period));
    float n100 = tb_hash13(mod(i + vec3(1.,0.,0.),    period));
    float n010 = tb_hash13(mod(i + vec3(0.,1.,0.),    period));
    float n110 = tb_hash13(mod(i + vec3(1.,1.,0.),    period));
    float n001 = tb_hash13(mod(i + vec3(0.,0.,1.),    period));
    float n101 = tb_hash13(mod(i + vec3(1.,0.,1.),    period));
    float n011 = tb_hash13(mod(i + vec3(0.,1.,1.),    period));
    float n111 = tb_hash13(mod(i + vec3(1.,1.,1.),    period));
    return mix(mix(mix(n000, n100, u.x), mix(n010, n110, u.x), u.y),
               mix(mix(n001, n101, u.x), mix(n011, n111, u.x), u.y), u.z);
}

// Cloud-like fbm in 0..1. Drifts along +X, loops every TB_LOOP seconds.
float tb_cloud(vec3 pos, float time) {
    float c = TB_CLOUD_CELLS;
    float phase = time / TB_LOOP;                 // 0..1 over one loop
    vec3 q = pos * (c / 16.0);                    // noise units, octave 1 period = c

    // octave 1: large blobs, one full period along X per loop
    vec3 q1 = q - vec3(phase * c, 0.0, 0.0);
    // octave 2: medium detail, same physical speed, slow wobble in Y
    vec3 q2 = q * 2.0 - vec3(phase * c * 2.0, 0.5 * sin(phase * TB_TAU), 0.0);
    // octave 3: fine detail, twice as fast, wobble in Z
    vec3 q3 = q * 4.0 - vec3(phase * c * 8.0, 0.0, 0.5 * cos(phase * TB_TAU));

    float n = 0.55 * tb_vnoise(q1, c)
            + 0.30 * tb_vnoise(q2, c * 2.0)
            + 0.15 * tb_vnoise(q3, c * 4.0);
    return n;
}

// Signed distance (in cells) to the nearest bubble; bubbles have slightly different radii
float tb_bubbles(vec3 p, float time) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    float sd = 8.0;
    for (int z = -1; z <= 1; z++)
    for (int y = -1; y <= 1; y++)
    for (int x = -1; x <= 1; x++) {
        vec3 g = vec3(float(x), float(y), float(z));
        vec3 cell = mod(i + g, TB_CELLS);
        vec3 o = tb_hash33(cell);
        o = 0.5 + 0.5 * sin(time * (TB_TAU / TB_LOOP) + TB_TAU * o);
        float r = mix(TB_BUBBLE_RMIN, TB_BUBBLE_RMAX, tb_hash13(cell + 17.3));
        sd = min(sd, length(g + o - f) - r);
    }
    return sd;
}

// pos  - any position in blocks (world position or section-local, only pos mod 16 matters)
// time - seconds (wraps every 12 s without a jump)
vec3 testBlockEffect(vec3 pos, float time) {
    pos = mod(pos, 16.0);

    // Cloud-like red-blue gradient
    float n = tb_cloud(pos, time);
    float t = smoothstep(0.28, 0.72, n);
    vec3 grad = mix(TB_RED, TB_BLUE, t);

    // White bubbles of varying size
    float sd = tb_bubbles(pos * TB_SCALE, time);
    float bubble = 1.0 - smoothstep(0.0, 0.07, sd);

    return mix(grad, vec3(1.0), bubble * 0.9);
}

// =====================================================================
//  test_instance_block: realistic drifting light-green clouds
// =====================================================================
const vec3  TI_MARKER = vec3(251.0, 13.0, 79.0) / 255.0;   // marker colour of the texture
bool ti_isMarker(vec3 rgb) {
    return all(lessThan(abs(rgb - TI_MARKER), vec3(1.5 / 255.0)));
}

// ---------- tweakables ----------
const float TI_LOOP    = 30.0;  // seconds for the clouds to drift one full 16-block period (smaller = faster)
const float TI_CELLS   = 8.0;   // biggest cloud blobs per 16 blocks (integer; bigger = smaller clouds)
const float TI_COVER_A = 0.42;  // cloud threshold: raise for fewer clouds
const float TI_COVER_B = 0.78;  // end of the soft edge
const vec3  TI_SKY     = vec3(0.30, 0.66, 0.48);  // background
const vec3  TI_SHADE   = vec3(0.50, 0.74, 0.56);  // cloud shadow side
const vec3  TI_LIT     = vec3(0.90, 1.00, 0.84);  // cloud lit side

// 4-octave periodic fbm (0..1). Every octave drifts along +X at the same physical speed.
float ti_fbm(vec3 q, float phase) {
    float c = TI_CELLS;
    float sum = 0.0;
    float amp = 0.5;
    float f = 1.0;
    for (int i = 0; i < 4; i++) {
        vec3 qi = q * f;
        qi.x -= phase * c * f;                              // one full period per loop
        qi.y += 0.5 * sin(phase * TB_TAU + float(i) * 1.7); // slow "boiling", loops seamlessly
        qi.z += 7.31 * float(i);
        sum += amp * tb_vnoise(qi, c * f);
        amp *= 0.5;
        f *= 2.0;
    }
    return sum / 0.9375;
}

vec3 testInstanceEffect(vec3 pos, float time) {
    pos = mod(pos, 16.0);
    float phase = time / TI_LOOP;
    float c = TI_CELLS;
    vec3 q = pos * (c / 16.0);

    // Domain warp -> wispy, billowy shapes instead of plain blobs
    vec3 qw = q * 0.5;
    qw.x -= phase * c * 0.5;
    vec3 warp = vec3(tb_vnoise(qw + vec3(3.1, 0.0, 0.0),  c * 0.5),
                     tb_vnoise(qw + vec3(0.0, 11.7, 0.0), c * 0.5),
                     tb_vnoise(qw + vec3(0.0, 0.0, 23.3), c * 0.5));
    q += (warp - 0.5) * 1.2;

    float d  = ti_fbm(q, phase);
    float cl = smoothstep(TI_COVER_A, TI_COVER_B, d);

    // Cheap cloud lighting: compare density with a sample shifted toward the light
    vec3 toLight = normalize(vec3(0.3, 0.8, 0.5));
    float d2 = ti_fbm(q + toLight * 0.12, phase);
    float lit = clamp(0.5 + (d - d2) * 7.0, 0.0, 1.0);
    vec3 cloud = mix(TI_SHADE, TI_LIT, lit);
    cloud = mix(cloud, TI_SHADE, 0.25 * smoothstep(0.65, 0.95, d)); // denser core is a bit darker

    return mix(TI_SKY, cloud, cl);
}

#endif
