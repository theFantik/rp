#version 330
#extension GL_ARB_separate_shader_objects : require

//#define PIXELATED

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:texture_sampling.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:terrainglobals.glsl>
#include <minecraft:test_block_effect.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chunkVisibility;
layout(location = 5) in vec3 globalPos;

#ifndef OIT_ALPHA_ONLY
layout(location = 11) in vec4 lightmapColor;
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

void main() {
    // Sample first, outside any branch (derivatives need uniform control flow)
    vec4 color = (UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize)) * vertexColor;

    // Marker: texture colour (12,250,77) means "test_block"
    vec4 texel = texelFetch(Sampler0, ivec2(texCoord0 * textureSize(Sampler0, 0)), 0);
    if (tb_isMarker(texel.rgb)) {
        vec3 p = globalPos;
        #ifdef PIXELATED
            p = floor(p * 16.) / 16.;
        #endif
        color = vec4(testBlockEffect(p, GameTime * 1200.0), 1.) * vertexColor;
    } else if (ti_isMarker(texel.rgb)) {
        vec3 p = globalPos;
        #ifdef PIXELATED
            p = floor(p * 16.) / 16.;
        #endif
        color = vec4(testInstanceEffect(p, GameTime * 1200.0), 1.) * vertexColor;
    }
    #ifndef OIT_ALPHA_ONLY
    color = mix(FogColor * vec4(1, 1, 1, color.a), color, chunkVisibility);
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
